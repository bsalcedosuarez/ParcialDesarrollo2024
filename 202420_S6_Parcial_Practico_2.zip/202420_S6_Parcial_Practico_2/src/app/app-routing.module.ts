import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PinguinoDetailComponent } from './pinguino/pinguino-detail/pinguino-detail.component';

const routes: Routes = [
  { path: 'pinguinos/:id', component: PinguinoDetailComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
