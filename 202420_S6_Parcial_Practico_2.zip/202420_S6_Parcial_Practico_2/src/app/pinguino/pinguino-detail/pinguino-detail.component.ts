import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PinguinoService } from '../pinguino.service';
import { Pinguino } from '../pinguino';

@Component({
  selector: 'app-pinguino-detail',
  templateUrl: './pinguino-detail.component.html',
  styleUrls: ['./pinguino-detail.component.css']
})
export class PinguinoDetailComponent implements OnInit {
  pinguinoDetail: Pinguino | null = null;
  pinguinos: Pinguino[] = [];
  errorMessage: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private pinguinoService: PinguinoService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.pinguinoService.getPinguinoById(id).subscribe(
        (pinguino) => {
          if (pinguino) {
            this.pinguinoDetail = pinguino;
          } else {
            this.errorMessage = `Pingüino con id ${id} no encontrado.`;
          }
        },
        (error) => {
          console.error('Error al obtener el pingüino', error);
          this.errorMessage = 'Error al obtener el pingüino.';
        }
      );
    } else {
      this.pinguinoService.getPinguinos().subscribe(
        (pinguinos) => {
          this.pinguinos = pinguinos;
        },
        (error) => {
          console.error('Error al obtener los pingüinos', error);
          this.errorMessage = 'Error al obtener los pingüinos.';
        }
      );
    }
  }

  goBack(): void {
    this.router.navigate(['/pinguinos']);
  }
}
