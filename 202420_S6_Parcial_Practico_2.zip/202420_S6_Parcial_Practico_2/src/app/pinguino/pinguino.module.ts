import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PinguinoListComponent } from './pinguino-list/pinguino-list.component';
import { PinguinoDetailComponent } from './pinguino-detail/pinguino-detail.component';
import { RouterModule } from '@angular/router';  // Asegúrate de importar RouterModule

@NgModule({
  declarations: [
    PinguinoListComponent,
    PinguinoDetailComponent
  ],
  exports: [
    PinguinoListComponent,
    PinguinoDetailComponent
  ],
  imports: [
    CommonModule,
    RouterModule  // Agrega RouterModule en los imports
  ]
})
export class PinguinoModule { }
