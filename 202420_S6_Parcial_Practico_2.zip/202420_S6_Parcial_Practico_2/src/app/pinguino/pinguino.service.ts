import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Pinguino } from './pinguino';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PinguinoService {
  baseUrl: string = 'https://gist.githubusercontent.com/fai-aher/0ea9284facf59d238269c4004dbcf277/raw/ba6109c62917339a9f1617d0a405506ed24c1ea7/penguin-species.json';

  constructor(private http: HttpClient) {}

  getPinguinos(): Observable<Pinguino[]> {
    return this.http.get<Pinguino[]>(this.baseUrl);
  }

  getPinguinoById(id: string): Observable<Pinguino | null> {
    return this.http.get<Pinguino[]>(this.baseUrl).pipe(
      map((pinguinos) => {
        const pinguino = pinguinos.find((p) => p.id === Number(id)); // Convertir id a número
        return pinguino || null; // Retornar el pingüino o null si no se encuentra
      })
    );
  }
}
